import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { patternValidator } from './pattern-validator';
import { CPFValidator } from './cpf-validator';
import { CepValidator } from './cep-validator';
import { CepService } from './cep-service';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css'],
  providers: [CepValidator]
})

export class FormularioComponent implements OnInit {

   public valueCep = false;
   public mascaraCpf = [ /\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '-',  /\d/, /\d/];
   public mascaraRg = [ /\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '.', /\d/, /\d/, /\d/, '-',  /\d/, /\d/];
   public mascaraTelefone = [ '(', /[1-9]/, /[1-9]/, ')' , /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/,  /\d/];
   public mascaraCep = [  /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/ ];

  formulario: FormGroup;

  constructor(private fb: FormBuilder, private cepValidator: CepValidator) {
   }

   createForm() {
     this.formulario = this.fb.group({
      name: ['', Validators.required],
      // tslint:disable-next-line:max-line-length
      email: ['', [Validators.required, patternValidator(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]],
      endereco: ['', Validators.required],
      cpf: ['', [Validators.required, CPFValidator]],
      rg: ['', Validators.required],
      telefone: ['', [Validators.required]],
      cep: ['', [Validators.required, this.cepValidator.BuscaCep.bind(this.cepValidator)]]
     });
   }

  ngOnInit() {
    this.createForm();

    this.formulario
    .statusChanges.subscribe(status => console.log(this.formulario));

  }
}

