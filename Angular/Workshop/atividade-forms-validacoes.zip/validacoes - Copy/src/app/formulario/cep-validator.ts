import { FormControl } from '@angular/forms';
import { CepService } from './cep-service';
import { Injector, Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { map } from 'rxjs/operators';
import { pipe, from, Observable } from 'rxjs';
import { Http } from '@angular/http';


@Injectable()
export class CepValidator  {
    constructor(public cepService: CepService) {  }

    public BuscaCep(control: FormControl) {

        let novoControle = control.value;

        if (control.value.length < 8) {
            const qtdZeros = 8 - control.value.length;
            for (let i = 0; i < qtdZeros; i++) {
                 novoControle +=  '0';
                 console.log(novoControle);
            }
        }

        return this.cepService.buscaCep(control.value).subscribe(resp => {
            if (resp.status === 200) {
                console.log(resp.status);
                return;
            } else {
                return {'cepInvalido': true};
            }
        });
    }
}
