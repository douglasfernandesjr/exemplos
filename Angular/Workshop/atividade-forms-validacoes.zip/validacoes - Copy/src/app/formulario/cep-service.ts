import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable,  } from 'rxjs';

@Injectable()
export class CepService {

    constructor(private http: Http) {}

    buscaCep(cep: number): Observable<any> {
        return this.http.get(`https://viacep.com.br/ws/${cep}/json/`)
                .pipe(map(res => res));
    }
}
