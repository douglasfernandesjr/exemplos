import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TextMaskModule } from 'angular2-text-mask';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ViacepModule } from '@brunoc/ngx-viacep';

import { AppComponent } from './app.component';
import { FormularioComponent } from './formulario/formulario.component';
import { CepValidator } from '../app/formulario/cep-validator';
import { CepService } from './formulario/cep-service';


@NgModule({
  declarations: [
    AppComponent,
    FormularioComponent,
  ],
  imports: [
    BrowserModule,
    TextMaskModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    ViacepModule
  ],
  providers: [CepService, CepValidator],
  bootstrap: [AppComponent]
})
export class AppModule { }
