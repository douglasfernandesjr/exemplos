import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SeriesComponent } from './series.component';

@Injectable()
export class SerieService {

    constructor(private http: Http) {

    }

    public RetornaPaginas(): Observable<any> {
        return this.http.get('https://tv-v2.api-fetch.website/shows')
               .pipe(map(Response => Response.json()));
    }

    public RetornaPaginasComSeries(pagina: string): Observable<any> {
        return this.http.get(`https://tv-v2.api-fetch.website/${pagina}?sort=name&order=1`)
               .pipe(map(Response => Response.json()));
    }

    public RetornaSerie(id: string): Observable<any> {
        return this.http.get(`https://tv-v2.api-fetch.website/show/${id}`)
               .pipe(map(Response => Response.json()));
    }
}

