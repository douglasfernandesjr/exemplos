import { Component, OnInit } from '@angular/core';
import { SerieService } from './serie.service';
import { map, tap } from 'rxjs/operators';
import { Observable, pipe } from 'rxjs';

@Component({
  selector: 'app-series',
  templateUrl: './series.component.html',
  styleUrls: ['./series.component.css']
})
export class SeriesComponent implements OnInit {

  paginasComSeries: any[] = [];
  series: any[] = [];
  value: any = '';
  private servico: SerieService;

  constructor(private serieService: SerieService) {
      this.servico = serieService;
    }

  ngOnInit() {
    this.servico.RetornaPaginas().pipe(
      tap(paginas => {
        paginas.forEach(pagina => {
          this.servico.RetornaPaginasComSeries(pagina)
            .subscribe(paginasComConteudo => this.paginasComSeries.push(paginasComConteudo));
        });
      })
    ).subscribe();

    setTimeout(() => {
      this.RetornaSeriesIndividuais();
    }, 2000);
  }

  RetornaSeriesIndividuais(): void {
    // this.paginasComSeries.forEach(pagina => {
    //   pagina.forEach(series => {
    //     this.series.push(series);
    //   });
    // });

    this.series = this.paginasComSeries[2];
    console.log(this.paginasComSeries[2]);
  }

  onKey(event: KeyboardEvent) {
    this.value = (<HTMLInputElement>event.target).value;
  }

  trasSerieDetalhada(id: string) {
    this.serieService.RetornaSerie(id)
      .subscribe(serie => console.log(serie));
  }

}

